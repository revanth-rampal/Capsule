# Bootstrap Animated Navigation Bar

A Pen created on CodePen.io. Original URL: [https://codepen.io/omerko96/pen/zjKBZG](https://codepen.io/omerko96/pen/zjKBZG).

Simple animation with bootstrap navigation bar. This i example is to show new guys out there how easy it can be,. Don't give up, learn every day.
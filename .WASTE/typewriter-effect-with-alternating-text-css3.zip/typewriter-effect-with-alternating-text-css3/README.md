# Typewriter effect with alternating text (CSS3)

A Pen created on CodePen.io. Original URL: [https://codepen.io/vasylenkoval/pen/PxoVXr](https://codepen.io/vasylenkoval/pen/PxoVXr).

